<?php 
if( isset( $_SERVER['HTTP_X_REQUESTED_WITH'] ) && ( $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest' ) )
{

    session_start();
    $nis=$_GET['nis'];
    $semester=$_SESSION['semester'];
    include_once '../../koneksi.php';
    $i=1;
    $query = $mysqli->query("SELECT DISTINCT pelajaran.id_pelajaran, pelajaran.semester, mapel.nama_mapel, guru.nama_guru from mapel, guru, pelajaran where pelajaran.nip = guru.nip and mapel.id_mapel = pelajaran.id_mapel AND pelajaran.nis='$nis' and pelajaran.semester='$semester'  order by guru.nama_guru  asc");
    $jsonResult = '{"data" : [ {'; $arr = array();


    while ($row=$query->fetch_assoc()) {

         $caripengetahuan=$mysqli->query("select id_pelajaran from nilai_pengetahuan where id_pelajaran='$row[id_pelajaran]'");
            $ketemupengetahuan = $caripengetahuan->num_rows;
            if ($ketemupengetahuan>0) 
            {
              $buttonpengetahuan="btn btn-success";
              $katapengetahuan="(Sudah)";
            }
            else
            {
              $buttonpengetahuan="btn btn-primary";
              $katapengetahuan="(Belum)";
            }

            $cariketerampilan=$mysqli->query("select id_pelajaran from nilai_keterampilan where id_pelajaran='$row[id_pelajaran]'");
            $ketemuketerampilan = $cariketerampilan->num_rows;
            if ($ketemuketerampilan>0) 
            {
              $buttonketerampilan="btn btn-success";
              $kataketerampilan="(Sudah)";
            }
            else
            {
              $buttonketerampilan="btn btn-primary";
              $kataketerampilan="(Belum)";
            }

            $carisikap=$mysqli->query("select id_pelajaran from nilai_sikap where id_pelajaran='$row[id_pelajaran]'");
            $ketemusikap = $carisikap->num_rows;
            if ($ketemusikap>0) 
            {
              $buttonsikap="btn btn-success";
              $katasikap="(Sudah)";
            }
            else
            {
              $buttonsikap="btn btn-primary";
              $katasikap="(Belum)";
            }


            $carinilai=$mysqli->query("select id_pelajaran from nilai where id_pelajaran='$row[id_pelajaran]'");
            $ketemunilai = $carinilai->num_rows;
            if ($ketemunilai>0) 
            {
              $buttonnilai="btn btn-success";
              $katanilai="(Sudah)";
            }
            else
            {
              $buttonnilai="btn btn-primary";
              $katanilai="(Belum)";
            }
        $sem=$row["semester"];
        $pelajaran=$row["id_pelajaran"];
    $link = "<a href='main_walikelas.php?url_walikelas=tampilnilaipengetahuan&nis=$nis&semester=$sem&id_pelajaran=$pelajaran' name='pengetahuan' class='$buttonpengetahuan' >Pengetahuan $katapengetahuan</a>
             <a href='main_walikelas.php?url_walikelas=tampilnilaiketerampilan&nis=$nis&semester=$sem&id_pelajaran=$pelajaran' name='keterampilan' class='$buttonketerampilan' >Keterampilan $kataketerampilan</a>
             <a href='main_walikelas.php?url_walikelas=tampilnilaisikap&nis=$nis&semester=$sem&id_pelajaran=$pelajaran' name='sikap' class='$buttonsikap' >Sikap $katasikap</a>
             <a href='main_walikelas.php?url_walikelas=prosesnilai&nis=$nis&semester=$sem&id_pelajaran=$pelajaran' name='pnilai' class='$buttonnilai' >Proses Nilai $katanilai </a>";
       $temp = array(
      "No" => $i,
        "Mata Pelajaran" => $row["nama_mapel"], 
        "Nama Guru" => $row['nama_guru'], 
        "Tampil Nilai" => $link);

       array_push($arr, $temp);
       $i++;
    }
    $data = json_encode($arr);
 
echo "{\"data\":" . $data . "}";
} else {
    echo '<script>window.location="404.html"</script>';
}

?>