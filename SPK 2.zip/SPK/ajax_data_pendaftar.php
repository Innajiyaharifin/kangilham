<?php 

    session_start();
    //$id_pendaftar=$_SESSION['id_pendaftar'];
    include_once 'library/activerecord.php';

        $table = "biodata,pengguna";
        $field = "pengguna.id_pengguna, pengguna.nama_lengkap, biodata.*";
        $where = "pengguna.id_pengguna=biodata.id_pengguna";
        $order = "pengguna.nama_lengkap";
        $sort = "asc";
        $activerecord = new activerecord;
        $proses = $activerecord->getOrder($table, $field,$where, $order, $sort);
        
/*<a href='index.php?menu=input_nilai&id=$row[id_pengguna]' class='btn btn-danger'>Kehadiran</a>
      <a href='index.php?menu=isian_wawancara&id=$row[id_pengguna]' class='btn btn-danger'>Kepatuhan</a>
      <a href='index.php?menu=isian_wawancara&id=$row[id_pengguna]' class='btn btn-danger'>Ketelitian</a>
      <a href='index.php?menu=isian_wawancara&id=$row[id_pengguna]' class='btn btn-danger'>Kerapihan</a>
      <a href='index.php?menu=isian_wawancara&id=$row[id_pengguna]' class='btn btn-danger'>Kecepatan</a>
      <a href='index.php?menu=isian_wawancara&id=$row[id_pengguna]' class='btn btn-danger'>Kebersamaan</a>
      */
    $jsonResult = '{"data" : [ {';
    $i=1;
    $arr = array();
    while ($row=$proses->fetch_assoc()) {
      $link = "

      <a href='index.php?menu=detail_pendaftar&id=$row[id_pengguna]' class='btn btn-primary'>Lihat Detail</a>
      ";

       $temp = array(
      "No" => $i,
        "Nama Lengkap" => $row['nama_lengkap'],
        "Jenis Kelamin" => $row["jenis_kelamin"],
        "Alamat Pendaftar" => $row["alamat_pendaftar"],
        "Lihat Detail" => $link);

       array_push($arr, $temp);
       $i++;
    }
    $data = json_encode($arr);
 
echo "{\"data\":" . $data . "}";


?>