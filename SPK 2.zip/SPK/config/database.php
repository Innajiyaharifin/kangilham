<?php 
//File ini Digunakan untuk pengaturan konfigurasi koneksi
$host="localhost";
$user="root";
$pass="";
$db="spk_kinerjakaryawan";







 ?>