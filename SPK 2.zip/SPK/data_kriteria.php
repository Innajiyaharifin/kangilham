	<div class="col-lg-12">
    	<h1 class="page-header">Data Karyawan</h1>
	</div>

	<div class="row">
		<div class="col-md-12">

			 <div class="table-responsive">

                <table class="table table-striped table-bordered table-hover" id="datakriteria">
                    <thead>
                        <tr>
                        	<th>No</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                </table>
            </div>
		</div>
		
	</div>
	
