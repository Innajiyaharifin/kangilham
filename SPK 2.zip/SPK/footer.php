 <footer style="    padding-left: 35%;
    padding-top: 15px;">
 &copy; <?php echo date('Y'); ?> <strong>SIMPEKI (Sistem Informasi Penilaian Kinerja Karyawan)</strong>. All rights reserved. <a href="http://smkmvp.sch.id">Ilham Reza</a>
  </footer>