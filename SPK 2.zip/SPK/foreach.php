<?php 
$nama[0] = array('0' => "1", '1'=> "sari susanti", '2'=> "admin", '3'=> "21232f297a57a5a743894a0e4a801fc3", '4'=> "-", '5'=> "-", '6'=> "1");
$nama[1] = array('0'=> "2", '1'=> "sari susanti", '2'=> "admin", '3'=> "21232f297a57a5a743894a0e4a801fc3", '4'=> "-", '5'=> "-", '6'=> "1");

foreach ($nama as $key => $nilai) 
{
	//echo $nilai[0];
}

$mysql_server = "localhost";
$mysql_user = "root";
$mysql_password = "";
$mysql_db = "spk_olimpiade";
$mysqli = new mysqli($mysql_server, $mysql_user, $mysql_password, $mysql_db);
if ($mysqli->connect_errno) {
	printf("Connection failed: %s \n", $mysqli->connect_error);
	exit();
}
$mysqli->set_charset("utf8");

$proses = $mysqli->query("SELECT * FROM pengguna");
$data = $proses->fetch_object();
var_dump($data);
/*$test = array('hah' => "tata", 'haha' =>"titi"  );
foreach ($test as $nilai) {
	echo $nilai;
	echo $key;
}*/


 ?>