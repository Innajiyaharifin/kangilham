<?php session_start(); 
require 'autoload.php';
if (empty($_SESSION['id_pengguna'])) {
    header("location: login.php");
}
else
{
    $id_pengguna = $_SESSION['id_pengguna'];
    if (empty($_SESSION['totalsoal'])) {
         $_SESSION['totalsoal']=1;
         $_SESSION['nilai']=0;
     } ?>
<!DOCTYPE html>
<html lang="en">

<?php include_once 'head.php'; ?>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php 
            if ($_SESSION['level']==0) {
                include_once 'navbar.php';
            }
            elseif ($_SESSION['level']==1) {
               include_once 'navbaradmin.php';
            }
            elseif ($_SESSION['level']==2) {
               include_once 'navbarhrd.php';
            }

         ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row" style="margin-top:70px">
                    <?php 
                    //mrmbuat flash message
                        if (isset($_SESSION['flash'])) {
                            ?>
                            <div class="alert alert-<?=$_SESSION['flash']['info']?>" >
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                 <?php echo $_SESSION['flash']['message']; ?>
                            </div>
                            <?php
                            unset($_SESSION['flash']);
                        }

                    //akhir

                        if (empty($_GET['menu'])) {
                           if (file_exists('home.php')) {
                                if ($_SESSION['level']==0) {
                                        include_once 'biodata.php';
                                    }
                                elseif ($_SESSION['level']==1) {
                                       include_once 'profil_admin.php';
                                    }
                           }
                        }
                        else
                        {
                            $menu=$_GET['menu'];
                            $halaman=$menu.".php";
                            if (file_exists($halaman)) {
                                include_once $halaman;
                           }
                           else
                           {
                                echo "404 Not Found";
                           }
                        }
                     ?>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<?php include_once 'footer.php'; ?>
 <?php include_once 'filejs.php'; ?>

</body>

</html>

    <?php
}
?>
