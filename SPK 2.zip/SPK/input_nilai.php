<?php 
$id= $_GET['id'];
$activerecord = new activerecord;
$proses = $activerecord->getWhere("pengguna as a, tb_nilai as b","*","b.id_pengguna='$id' and a.id_pengguna = b.id_pengguna");
if ($data=$proses->fetch_object()) {
  //$nw = $data->kepatuhan;
  //$na = $data->kh;

}
else
{
  $nw ="";
  $na = "";
}
 ?>

<div class="row">
	<div class="col-lg-12">
        <h1 class="page-header">Input Nilai</h1>
	</div>
</div>
    <!-- /.col-lg-12 -->
<div class="row" >
    <div class="col-lg-12">

   	<form action="proses_inputnilai.php" method="POST" role="form">
   	
   		<!--<div class="form-group">
   			<label for="">Nilai Wawancara</label>
   			<input type="text" name="nilaiw" value="<?php echo $nw ?>" class="form-control" id="" placeholder="0-100">
   		</div>-->
   		<div class="form-group">
   			<label for="">Kehadiran</label>
   			<!--<input type="text" name="nilaia" value="<?php echo $na ?>" class="form-control" id="" placeholder="0-100">-->
   		</div>
   		<input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
      <label>Dalam sebulan, berapa kali Karyawan bersangkutan tidak masuk(Absen) ?</label> <br>
      <input type="radio" name="kehadiran" value="20"> Lebih Dari 3 kali <br>
      <input type="radio" name="kehadiran" value="40"> 3 kali <br>
      <input type="radio" name="kehadiran" value="60"> Kurang Dari 3 kali <br>
      <input type="radio" name="kehadiran" value="100"> Tidak Pernah Absen <br>

   	
   		
   	
   		<button type="submit" name="submit" class="btn btn-primary">Submit</button>
   	</form>
    </div>

</div>
