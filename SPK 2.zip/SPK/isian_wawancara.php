<?php 

$totalsoal = $_SESSION['totalsoal'];
$id_pengguna = $_SESSION['id_pengguna'];
$activerecord = new activerecord;

$proses = $activerecord->getWhere("tb_nilai","*","id_pengguna = '$id_pengguna'");


 ?>
<div class="container">
	<div class="row">
		<div class=" col-md-12">
			<div class="panel panel-default">
				  <div class="panel-heading">
						
				  </div>
				  <div class="panel-body">
				  	<form action="proses_nilai_wawancara.php" method="POST" accept-charset="utf-8">
						<?php 
								$activerecord = new activerecord;
								$proses = $activerecord->getWhere("kepribadian","*","kode_prib='C01'");?>
	  					 		<?php if($proses->num_rows >0) : $i = 0; ?>
								<?php while($data =$proses->fetch_assoc()):?>			
  								<table id="" class="table table-bordered table-hover">
                  <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  										<select name="opsi30">
  											<option value="1">Sama Penting Dengan</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C02'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
  									<select name="opsi1">
  											<option value="1">Sama Penting Dengan</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C03'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>		</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
  									<select name="opsi2">
  											<option value="1">Sama Penting Dengan</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C04'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>		</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
  									<select name="opsi3">
  											<option value="1">Sama Penting Dengan</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  																<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C05'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?></tr>
  								  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  									<select name="opsi4">
  											<option value="1">Sama Penting Dengan</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C06'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>

  								</table>
											  						<?php endwhile; ?>
  							<?php endif; ?>
<?php 
								$activerecord = new activerecord;
								$proses = $activerecord->getWhere("kepribadian","*","kode_prib='C02'");?>
	  					 		<?php if($proses->num_rows >0) : $i = 0; ?>
								<?php while($data =$proses->fetch_assoc()):?>			
  								<table id="" class="table table-bordered table-hover">
	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  										<select name="opsi5">
  											<option value="1/3">Sedikit Lebih Penting Dari</option>
  											<option value="1/5">Lebih Penting Dari</option>
  											<option value="1/7">Lebih Mutlak Penting Dari</option>
  											<option value="1/9">Mutlak Penting Dari</option>
  											<option value="1/2">Nilai Berdekatan Dari</option>
	</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C01'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
                    <select name="opsi6">
                        <option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
                      </select>
                    									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C03'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>		</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
                    <select name="opsi7">
                        <option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C04'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>		</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
                    <select name="opsi8">
                        <option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  																<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C05'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?></tr>
  								  <tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
                    <select name="opsi9">
                        <option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  																<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C06'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?></tr>				
  								</tr>

  								</table>
											  						<?php endwhile; ?>
  							<?php endif; ?>
<?php 
								$activerecord = new activerecord;
								$proses = $activerecord->getWhere("kepribadian","*","kode_prib='C03'");?>
	  					 		<?php if($proses->num_rows >0) : $i = 0; ?>
								<?php while($data =$proses->fetch_assoc()):?>			
  								<table id="" class="table table-bordered table-hover">
	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
                    <select name="opsi10">
                        <option value="1/3">Sedikit Lebih Penting Dari</option>
                        <option value="1/5">Lebih Penting Dari</option>
                        <option value="1/7">Lebih Mutlak Penting Dari</option>
                        <option value="1/9">Mutlak Penting Dari</option>
                        <option value="1/2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C01'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>
	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
                    <select name="opsi11">
                        <option value="1/3">Sedikit Lebih Penting Dari</option>
                        <option value="1/5">Lebih Penting Dari</option>
                        <option value="1/7">Lebih Mutlak Penting Dari</option>
                        <option value="1/9">Mutlak Penting Dari</option>
                        <option value="1/2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C02'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>

  								</tr>
  									  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
                    <select name="opsi12">
                        <option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C04'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>

  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
                    <select name="opsi13">
                        <option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C05'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>		</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
                    <select name="opsi14">
                        <option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C06'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>		</tr>
  								</tr>

  								</table>
											  						<?php endwhile; ?>
  							<?php endif; ?>
<?php 
								$activerecord = new activerecord;
								$proses = $activerecord->getWhere("kepribadian","*","kode_prib='C04'");?>
	  					 		<?php if($proses->num_rows >0) : $i = 0; ?>
								<?php while($data =$proses->fetch_assoc()):?>			
  								<table id="" class="table table-bordered table-hover">
	  								  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
                    <select name="opsi15">
                        <option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C01'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>
 	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
                    <select name="opsi16">
                        <option value="1/3">Sedikit Lebih Penting Dari</option>
                        <option value="1/5">Lebih Penting Dari</option>
                        <option value="1/7">Lebih Mutlak Penting Dari</option>
                        <option value="1/9">Mutlak Penting Dari</option>
                        <option value="1/2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C02'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>
	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
                    <select name="opsi17">
                        <option value="1/3">Sedikit Lebih Penting Dari</option>
                        <option value="1/5">Lebih Penting Dari</option>
                        <option value="1/7">Lebih Mutlak Penting Dari</option>
                        <option value="1/9">Mutlak Penting Dari</option>
                        <option value="1/2">Nilai Berdekatan Dari</option>
                      </select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C03'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>

	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  										<select name="opsi18">
  											<option value="1">Sama Dengan</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C05'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
  										<select name="opsi19">
  											<option value="1">Sama Dengan</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C06'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>	</tr>

  								</table>
											  						<?php endwhile; ?>
  							<?php endif; ?>
<?php 
								$activerecord = new activerecord;
								$proses = $activerecord->getWhere("kepribadian","*","kode_prib='C05'");?>
	  					 		<?php if($proses->num_rows >0) : $i = 0; ?>
								<?php while($data =$proses->fetch_assoc()):?>			
  								<table id="" class="table table-bordered table-hover">
	  								  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  										<select name="opsi20">
  										<option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C01'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>
	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  										<select name="opsi21">
  										<option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C02'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>
	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  										<select name="opsi22">
  											<option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C03'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>
	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  										<select name="opsi23">
  											<option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C04'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>

	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  										<select name="opsi24">
  											<option value="1">Sama Penting Dengan</option>
                        <option value="3">Sedikit Lebih Penting Dari</option>
                        <option value="5">Lebih Penting Dari</option>
                        <option value="7">Lebih Mutlak Penting Dari</option>
                        <option value="9">Mutlak Penting Dari</option>
                        <option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C06'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>
  							<?php 
								$activerecord = new activerecord;
								$proses = $activerecord->getWhere("kepribadian","*","kode_prib='C06'");?>
	  					 		<?php if($proses->num_rows >0) : $i = 0; ?>
								<?php while($data =$proses->fetch_assoc()):?>			
  								<table id="" class="table table-bordered table-hover">
	  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  										<select name="opsi25">
  											<option value="1">Sama Penting Dengan Kualitas</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C02'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
  									<select name="opsi26">
  											<option value="1">Sama Penting Dengan Kualitas</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C03'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>		</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
  									<select name="opsi27">
  											<option value="1">Sama Penting Dengan Kualitas</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C04'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>		</tr>
  								<tr>
	  							<td><label><?=$data['nama_prib']?>	</label></td>
  									
  									<td>
  									<select name="opsi28">
  											<option value="1">Sama Penting Dengan Kualitas</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>
  																<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C05'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?></tr>
  								  							<tr>
	  								<td><label><?=$data['nama_prib']?>	</label></td>
  		 							<td>
  									<select name="opsi29">
  											<option value="1">Sama Penting Dengan Kualitas</option>
  											<option value="3">Sedikit Lebih Penting Dari</option>
  											<option value="5">Lebih Penting Dari</option>
  											<option value="7">Lebih Mutlak Penting Dari</option>
  											<option value="9">Mutlak Penting Dari</option>
  											<option value="2">Nilai Berdekatan Dari</option>
  										</select>
  									</td>

  														<?php
								$activerecord1 = new activerecord;
								$proses1 = $activerecord1->getWhere("kepribadian","*","kode_prib='C01'");?>
	  					 		<?php if($proses1->num_rows >0) : $i = 0; ?>
								<?php while($data1 =$proses1->fetch_assoc()):?>			

  									 <td><label><?=$data1['nama_prib']?>	</label></td>

  							<?php endwhile; endif; 
  							?>

  								</tr>

  								</table>
											  						<?php endwhile; ?>
  							<?php endif; ?>
 								</table>
											  						<?php endwhile; ?>
  							<?php endif; ?>

											<?php
										
										
										echo "<br><button class=\"btn btn-primary\" type=\"submit\">Submit</button>";
									
													 ?>
						 	
						 </form>
				  </div>
			</div>
		</div>
	</div>
</div>
<?php ?>

