<!DOCTYPE html>
<html lang="id">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title></title>

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/bgslide.css">
		<link rel="icon" type="image/png" href="images/mvp.png">
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="js/html5shiv.min.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
		
	</head>
	<body style="background-color: grey !important">
		<div id="bg-slideshow" >
			<!--<img src="images/abcde.jpg">-->
			
		</div>
		<nav class="navbar navbar-default"  role="navigation">
			<!-- Brand and toggle get grouped for better mobile display -->
			<!-- container disimpen setelah nav agar navbar nya tidak terganggu, jadi hanya
				tataletak iconnya saja yang diatur sesuai containernya-->
			<div class="container">
				<div class="navbar-header">
				<!--fungsi button dibawah ini hanya akan aktif jika mode layar kecil
				akan terlihat 1 tombol dengan 3 bar( ada strip2 3 batang) -->
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span><!-- ini  batang 1 -->
						<span class="icon-bar"></span><!-- ini  batang 2 -->
						<span class="icon-bar"></span><!-- ini  batang 3 -->
					</button>
					<!-- navbar brand adalah clas untuk menampilkan logo,, logo bisa berupa tulisan atau gambar-->
					<b><a class="navbar-brand" href="" style="padding:10px 10px 10px 10px;"></a></b>
				</div>
				
				<!-- fungsi navbar collapse sebagai tombol di button yang ada di navbar
					di dalamnya ada 2 <ul>, ul yang pertama membuat kumpulan link/tombol dibagian kiri, dan ul
					yang kedua di buat rata kanan , disini digunakan untuk membuat dropdown
				 Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-ex1-collapse">
					<ul class="nav navbar-nav">
						<li><a href="#">SIMPEKI (Sistem Informasi Penilaian Kinerja Karyawan)</a></li>
					</ul>
				</div><!-- /.navbar-collapse -->
			</div><!--akhir container-->
		</nav>
		<div class="container">
			<div class="row">
			<!-- disini layout sebelah kiri,, yang meliputi jumbotron dll.... -->


				<div class="col-md-8 hidden-xs hidden-sm">
				<!-- Button trigger modal -->


					<div class="jumbotron" align="center" style="background-color:rgba(238, 238, 238, 0);">
					  <h1 style="color: #F1EEEE">Selamat Datang</h1>
					  <h3 style="color: #F1EEEE">SIMPEKI (Sistem Informasi Penilaian Kinerja Karyawan)</h3><br>
					  <p style="color: #F1EEEE">Pelajari selengkapnya untuk cara masuk</p>
					  <p><a class="btn btn-primary btn-lg" href="#" role="button"  data-toggle="modal" data-target="#caramasuk">Selengkapnya<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a></p>
					</div>
				</div>


			<!-- disini layout sebelah kanan yang isinya ada panel dan form -->
				<div class="col-md-4">
					<div class="panel panel-default" style="margin-top:50px">
						<div class="panel-body">
							<div class="page-header">
								<h3 align="center" >Masuk</h3>
							</div>
							<form action="proseslogin.php" method="POST">
								<div class="form-group">
									<label for="username">Nama Pengguna</label>
										<div class="input-group">
											<span class="input-group-addon" ><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>
											<input autofocus type="text" class="form-control" name="username" placeholder="Masukan Nama Pengguna">	
										</div>
									
								</div>
								<div class="form-group">
									<label>Kata Sandi</label>
										<div class="input-group">
											<span class="input-group-addon"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span></span>
											<input type="password" class="form-control" name="password" placeholder="Masukan Kata Sandi">	
										</div>
									
								</div>
				
										
								
									<button type="submit" class="btn btn-primary" name="simpan">Masuk</button> 
									
										<div class="pull-right" style="padding-top:15px;">
											<a href="formlupapassword.php">Lupa kata sandi?</a>
										</div>
							</form>
						</div>						
					</div>
				</div>
				
			</div>			
		</div>
			







<!-- Modal -->
<div class="modal fade" id="caramasuk" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 align="center"class="modal-title" id="myModalLabel">Cara Masuk</h4>
      </div>
      <div class="modal-body">
      <h5><b>Saat ini anda Sedang Berada di halaman Login SIMPEKI (Sistem Informasi Penilaian Kinerja Karyawan)</b></h3>
      Agar Anda dapat masuk ke SIMPEKI
      <ol>
      <li>Klik tombol daftar pada halaman website jika anda belum memiliki username dan password</li>
      <li>Masukan Nama Pengguna atau username yang Anda Miliki</li>
      <li>Masukan Kata Sandi atau Password yang Anda miliki</li>
      <li>Kemudian Klik Tombol Login</li>
      </ol>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--akhir modal-->








		<!-- jQuery -->
		<script src="js/jquery.min.js"></script>
				<!-- Bootstrap JavaScript -->
		<script src="js/bootstrap.min.js"></script>
		<script type="text/javascript">
		$('#caramasuk').on('shown.bs.modal')</script>
	</body>
</html>
