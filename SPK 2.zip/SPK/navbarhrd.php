        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" style="padding:10px 10px 10px 10px;"href="#" ></a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav hidden-xs">
                <li><b><a href="">SIMPEKI (Sistem Informasi Penilaian Kinerja Karyawan)</a></b></li>
            </ul>
            
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
                
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div style="position: fixed;" class="navbar-default sidebar affix-top" role="navigation">
                <div class="sidebar-nav navbar-collapse ">
                    <ul class="nav" id="side-menu">
                        <li>
                            <h4 style="margin: 15px">Menu HRD</h4>
                        </li>
                         <li>
                            <a href="index.php?menu=profil_admin"><i class="fa fa-user fa-fw"></i>Profil</a>
                        </li>
                        <li>
                            <a href="index.php?menu=data_pendaftar"><i class="fa fa-users fa-fw"></i>Data Karyawan</a>
                        </li>
                      
                        <li>
                            <a href="index.php?menu=seleksihrd"><i class="fa fa-check-square-o fa-fw"></i>Hasil Seleksi</a>
                        </li>
                        <!--<li>
                            <a href="index.php?menu=laporanditerima"><i class="fa fa-bar-chart fa-fw"></i>Laporan</a>
                        </li>
                        <li>
                            <a href="index.php?menu=buatsoal"><i class="fa fa-edit fa-fw"></i>Buat Soal</a>
                        </li>
                        <li>
                            <a href="index.php?menu=tambahadmin"><i class="fa fa-gears fa-fw"></i>Pengaturan</a>
                        </li>-->
                        <li>
                            <a href="keluar.php"><i class="fa fa-sign-out fa-fw"></i>Keluar</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>