	<div class="col-lg-12">
    	<h1 class="page-header">Bank Soal  <a href="index.php?menu=buatsoal" class="btn btn-default">Kembali</a></h1>
	</div>

	<div class="row">
		<div class="col-md-12">

			 <div class="table-responsive">

                <table class="table table-striped table-bordered table-hover" id="semuasoal">
                    <thead>
                        <tr>
                        	<th>No</th>
                            <th>Kriteria</th>
                            <th>Soal</th>
                            <th>Jawaban 100% </th>
                            <th>Jawaban 75%</th>
                            <th>Jawaban 50%</th>
                            <th>Jawaban 25%</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                </table>
            </div>
		</div>
		
	</div>