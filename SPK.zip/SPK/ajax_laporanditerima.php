<?php

include_once 'library/activerecord.php';
$activerecord= new activerecord;
$q = $activerecord->getAll("tb_kuota");
if ($kuota=$q->fetch_object()) {
	$quota = $kuota->kuota;
	$grade = $kuota->passing_grade;
}
$proses=$activerecord->getWhere("tb_nilai,pengguna","*,COUNT(*) as hitung","pengguna.id_pengguna=tb_nilai.id_pengguna and tb_nilai.total_hasil >= $grade GROUP BY tb_nilai.tahun limit $quota");
			
$data=array();
//loooooooooop sebagai object, bisa pake fetch_array $row['field']
while ($row = $proses->fetch_object()) {
	$tahun= $row->tahun;
	$tahun = $tahun;
	$data[]=array(
		'y'=>$tahun, //y sebagai kata kunci nya (tahun)		
		'jumlah'=>$row->hitung, //jumlah penjualan
		);	
}
	//outputkan sebagai json
	echo json_encode($data);
?>