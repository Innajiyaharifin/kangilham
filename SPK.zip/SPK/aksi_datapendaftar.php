<?php 
if (isset($_GET['aksi'])) 
{
    $aksi=$_GET['aksi'];
    if ($aksi=="simpan") 
    {
        if (isset($_POST['submit'])) {
    include_once 'library/activerecord.php';
    $nilaiw=$_POST['nilaiw'];
    $nilaia=$_POST['nilaia'];
    $id_pengguna = $_POST['id'];
    
    $activerecord = new activerecord;
    $proses = $activerecord->getWhere("tb_nilai","*","id_pengguna='$id_pengguna'");
    $ketemu = $activerecord->numRows($proses);
    if ($ketemu>0) {
        $proses = $activerecord->getUpdate("tb_nilai","nilai_administrasi='$nilaia', nilai_wawancara='$nilaiw'","id_pengguna='$id_pengguna'");
    }
    else
    {
        $proses = $activerecord->getInsert("tb_nilai","'','$id','$nilaiw','$nilaia',''");
    }
    if ($proses) {
        $prosestampil = $activerecord->getWhere("tb_nilai","*","id_pengguna='$id_pengguna'");
        if($data = $activerecord->fetch($prosestampil))
        {
            $total = ($data->nilai_administrasi + $data->nilai_wawancara + $data->nilai_ujian)/3;
            $proses = $activerecord->getUpdate("tb_nilai","total_hasil='$total'","id_pengguna='$id_pengguna'");
            if ($proses) {
                header("location: index.php?menu=data_pendaftar");
                //echo($total);
            }
            else
            {
                echo "Galal".$activerecord->error();
            }
        }
    }
    else
    {
        echo "Gagal";
    }

    
    

    
}

 ?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Input Nilai</h1>
    </div>
</div>
    <!-- /.col-lg-12 -->
<div class="row" >
    <div class="col-lg-12">

    <form action="proses_inputnilai.php" method="POST" role="form">
        <legend>Form title</legend>
    
        <div class="form-group">
            <label for="">Nilai Wawancara</label>
            <input type="text" name="nilaiw" class="form-control" id="" placeholder="0-100">
        </div>
        <div class="form-group">
            <label for="">Nilai Administrasi</label>
            <input type="text" name="nilaia" class="form-control" id="" placeholder="0-100">
        </div>
        <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
    
        
    
        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
    </form>
    </div>

</div>

 <?php 

        if (isset($_POST['edit'])) 
        {
            $nip=addslashes($_POST['nip']);
            $nama_guru=addslashes($_POST['nama_guru']);
            $alamat_guru=addslashes($_POST['alamat_guru']);
            $tanggallahir_guru=addslashes($_POST['tanggallahir_guru']);
            $tempatlahir_guru=addslashes($_POST['tempatlahir_guru']);
            $keahlian=addslashes($_POST['keahlian']);
            $status_wali_kelas=addslashes($_POST['status_wali_kelas']);
            $kode_kelas=addslashes($_POST['kode_kelas']);
            $password_guru=md5(addslashes($_POST['tanggallahir_guru']));
            $jenis_kelamin_guru=addslashes($_POST['jk']);
            $no_telpon_guru=addslashes($_POST['no_telpon_guru']);
            $email_guru=addslashes($_POST['email_guru']);

            //untuk photo_guru
                $photo_guru = $_FILES['photo_guru']['name']; // berisi nama file yang sedang di photo_guru
                $tipeFile = $_FILES['photo_guru']['type']; // mime type dari file yang sedang di photo_guru, jika browser memberikan informasi ini. Contoh : image/gif, image/jpg dll
                $ukuranFile = $_FILES['photo_guru']['size']; // ukuran size file yang diphoto_guru dalam byte
                $errorFile = $_FILES['photo_guru']['error']; // error code yang berhubungan dengan file yang sedang di photo_guru
                $direktori_photo_guru = "../images/guru/$photo_guru";
                //cek photo_guru bener ga?
                
                    if($ukuranFile > 0 || $errorFile == 0)
                    {
                            /* 
                                $_FILES['photo_guru']['tmp_name'] adalah nama file temporer dari file yang sedang diupload yang disimpan di temporari folder server
                                move_uploaded_file adalah fungsi untuk mengupload file dari direktori klien ke server
                            */
                            $move = move_uploaded_file($_FILES['photo_guru']['tmp_name'], $direktori_photo_guru );
                            
                            // perintah SQL untuk melakukan input data
                            
                            include_once '../koneksi.php';
                            $proses=$mysqli->query("update guru set nama_guru='$nama_guru', alamat_guru='$alamat_guru', jenis_kelamin_guru='$jenis_kelamin_guru', tempatlahir_guru='$tempatlahir_guru', tanggallahir_guru='$tanggallahir_guru', keahlian='$keahlian', status_wali_kelas='$status_wali_kelas', id_kelasjurusan='$kode_kelas', photo_guru='$photo_guru', no_telpon_guru='$no_telpon_guru', email_guru='$email_guru' where nip='$id'");
                            
                            if($move && $proses)
                            {
                                $_SESSION['flash']['pesan']="Data Berhasil Diubah";
                                $_SESSION['flash']['info']="success";
                                echo "<script>document.location = 'main_admin.php?url_admin=dataguru'</script>";
                            }
                            else
                            {
                                echo "<script>alert('gagal')".$mysqli->error."</script>";

                            }
                    }
                    else
                    {
                        include_once '../koneksi.php';
                            $proses=$mysqli->query("update guru set nama_guru='$nama_guru', alamat_guru='$alamat_guru', jenis_kelamin_guru='$jenis_kelamin_guru', tempatlahir_guru='$tempatlahir_guru', tanggallahir_guru='$tanggallahir_guru', keahlian='$keahlian', status_wali_kelas='$status_wali_kelas', id_kelasjurusan='$kode_kelas',no_telpon_guru='$no_telpon_guru', email_guru='$email_guru' where nip='$id'");
                            if($proses)
                            {
                                $_SESSION['flash']['pesan']="Data Berhasil Diubah";
                                $_SESSION['flash']['info']="success";
                                //echo "<script>document.location = 'main_admin.php?url_admin=dataguru'</script>";
                            }
                            else
                            {
                                echo "<script>alert('gagal')".$mysqli->error."</script>";

                            }
                    }
                    
        
                }
            }
        }




        elseif ($aksi=="hapus") 
        {
            if (isset($_GET['id'])) 
            {
                $id=$_GET['id'];
                include_once '../koneksi.php';
                $proses=$mysqli->query("delete from guru where nip='$id'");
                if ($proses)    
                {
                    $_SESSION['flash']['pesan']="Data Berhasil Dihapus";
                    $_SESSION['flash']['info']="success";
                echo "<script> document.location='main_admin.php?url_admin=dataguru'</script>";
                }
                else 
                {   

                    echo "<script> alert('Data gagal di Hapus');</script>";
                }
            }
        }


        elseif ($aksi=="detail") 
        {
            if (isset($_GET['id'])) 
            {
                $id=$_GET['id'];
                include_once '../koneksi.php';
                ?>
                    <div class="col-lg-12">
        <h1 class="page-header">Data Guru</h1>
    </div>

    <div class="row">
        <div class="col-md-2 col-xs-6">
        <?php  
                 
        $no=1;
        $id=$_GET['id'];
        $proses=$mysqli->query("select * from guru where nip='$id' order by nip ");
        $data=$proses->fetch_object();
                                                
                                         ?>

            <img width="150px" height="150spx" src="../images/guru/<?php echo $data->photo_guru; ?>">
                    
        </div>
        <div class="col-md-6">

            <div >
                <div>
                    <table class="table table-hover" >
                        <tr class="warning">
                            <td>NIP</td>
                            <td>:</td>
                            <td><?php echo $data->nip; ?></td>
                            
                        </tr>
                        <tr>
                            <td>Nama</td>
                            <td>:</td>
                            <td><?php echo $data->nama_guru; ?></td>
                            
                        </tr>
                        <tr class="warning">
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?php echo $data->alamat_guru; ?></td>
                            
                        </tr>
                        <tr>
                            <td>No Telpon</td>
                            <td>:</td>
                            <td><?php echo $data->no_telpon_guru; ?></td>
                        </tr>
                        <tr class="warning">
                            <td>Email</td>
                            <td>:</td>
                            <td><?php echo $data->email_guru; ?></td>
                        </tr>
                        <tr >
                            <td>Jenis Kelamin</td>
                            <td>:</td>
                            <td><?php 
                                    if ($data->jenis_kelamin_guru=="p") {
                                        echo "Perempuan";
                                    }
                                    else
                                    {
                                        echo "Laki-laki";
                                    }
                            ?></td>
                        </tr>
                        <tr class="warning">
                            <td>Tempat Lahir</td>
                            <td>:</td>
                            <td><?php echo $data->tempatlahir_guru; ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Lahir</td>
                            <td>:</td>
                            <td><?php echo $data->tanggallahir_guru; ?></td>
                        </tr>
                        <tr class="warning">
                            <td>Keahlian</td>
                            <td>:</td>
                            <td><?php echo $data->keahlian; ?></td>
                        </tr>
                        <tr>
                            <td>Status Wali Kelas</td>
                            <td>:</td>
                            <td><?php if ($data->status_wali_kelas=='1') {
                                                        echo "Ya";
                                                    }
                                                    else
                                                        echo "Tidak";?></td>
                        </tr>
                        <tr class="warning">
                            <td>Terakhir Login</td>
                            <td>:</td>
                            <td><?php
                                              include_once '../selisihtime.php';
                                                date_default_timezone_set("asia/jakarta");
                                                    $tglsekarang=date("Y/m/d h:i:s");
                                                    $log=$tglsekarang-$data->log;
                                                    echo xtimeAgo($data->log,$tglsekarang,'d');
                                                    

                                               ?></td>
                        </tr>
                        </table>
                        
                </div>
            </div>
        </div>
        
    </div>
    

                    <?php 
            } 
        }
}
                    ?>