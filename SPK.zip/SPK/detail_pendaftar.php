<?php 
$id=abs((int)$_GET['id']);
$activerecord = new activerecord;
$cari = $activerecord->getWhere("biodata,pengguna","*","biodata.id_pengguna='$id' and biodata.id_pengguna=pengguna.id_pengguna order by biodata.id_pendaftar desc limit 1");
$ketemu = $cari->num_rows;
if ($ketemu>0) {
	$data = $cari->fetch_object();
	$nama = $data->nama_lengkap;
	$email = $data->email;
	$jk = $data->jenis_kelamin;
	$tempat = $data->tempat_lahir;
	$alamat= $data->alamat_pendaftar;
	$tanggal= $data->tanggal_lahir;
	$asalsekolah= $data->asal_sekolah;
	$hp = $data->no_hp;
	$telepon = $data->telepon_rumah;
	//$button_simpan = "";
	//$button_edit = "<a href='index.php?menu=editbiodata' class=\"btn btn-danger\" name=\"edit\">EDIT</a>";
	/*$gambar = "<div class=\"form-group\">
							<label for=\"\">Unggah Gambar</label>
							<input disabled  type=\"file\" name=\"gambar\">
						</div>";
*/
}
else
{
	$nama = "";
	$email = "";
	$jk = "";
	$tempat = "";
	$alamat= "";
	$tanggal= "";
	$asalsekolah= "";
	$hp = "";
	$telepon = "";
	//$button_edit = "";
	//$button_simpan = "<button type=\"submit\" class=\"btn btn-primary\" name=\"simpan\">SIMPAN</button>";
	/*$gambar = "<div class=\"form-group\">
							<label for=\"\">Unggah Gambar</label>
							<input disabled  type=\"file\" name=\"gambar\">
						</div>";*/
}	
 ?>

<div class="row">
	<div class="col-lg-12">
        <h1 class="page-header">Biodata Siswa</h1>
	</div>
</div>
    <!-- /.col-lg-12 -->
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<form action="prosesbiodata.php" enctype="multipart/form-data" method="POST" role="form">
		
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Nama</label>
							<input disabled  type="text" name="nama" value="<?php echo $nama; ?>" class="form-control" id="" placeholder="Cth: Sutarman">
						</div>
					</div>
					<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
						<div class="form-group">
							<label for="">Email</label>
							<input disabled  type="text" name="email" value="<?php echo $email; ?>" class="form-control" id="" placeholder="Cth: contoh@example.com">
						</div>
		 			</div>
		 		</div>
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Jenis Kelamin</label>
							<div class="radio">
								<label>
									<input disabled  type="radio" name="jk" id="input" value="" checked="checked">
									Laki-laki
								</label>
								<label>
									<input disabled  type="radio" name="jk" id="input" value="">
									Perempuan
								</label>
							</div>
						</div>

		 			</div>
		 		</div>
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Tempat Lahir</label>
							<input disabled  type="text" value="<?php echo $tempat; ?>" name="tempat" class="form-control" id="" placeholder="Cth: Bandung">
						</div>
					</div>
					<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
						<div class="form-group">
							<label for="">Tanggal Lahir</label>
							<input disabled  type="text" value="<?php echo $tanggal ?>" name="tanggal" class="form-control" id="" placeholder="Cth: 1995-08-01">
						</div>
		 			</div>
		 		</div>
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Alamat Rumah</label>
							<input disabled  type="text" value="<?php echo $alamat; ?>" name="alamat" class="form-control" id="" placeholder="Cth: Jalan Siliwangi, Bandung">
						</div>
					</div>
					<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
						<div class="form-group">
							<label for="">Asal Sekolah</label>
							<input disabled  type="text" value="<?php echo $asalsekolah ?>" name="asalsekolah" class="form-control" id="" placeholder="Cth: SMKN 1 Bandung">
						</div>
		 			</div>
		 		</div>
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Telepon</label>
							<input disabled  type="text" name="telepon" value="<?php echo $telepon ?>" class="form-control" id="" placeholder="Cth: 022678768">
						</div>
					</div>
					<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
						<div class="form-group">
							<label for="">HP</label>
							<input disabled  type="text" name="hp" value="<?php echo $hp ?>" class="form-control" id="" placeholder="Cth: 089699929549">
						</div>
		 			</div>
		 		</div>
		 		
		 		

		 		
				

		
			
		
		</form>
	</div>
</div>
