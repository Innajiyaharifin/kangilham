<?php 

$activerecord = new activerecord;
$cari = $activerecord->getWhere("biodata,pengguna","*","biodata.id_pengguna='$id_pengguna' and biodata.id_pengguna=pengguna.id_pengguna order by biodata.id_pendaftar desc limit 1");
$ketemu = $cari->num_rows;
if ($ketemu>0) {
	$data = $cari->fetch_object();
	$id=$data->id_pendaftar;
	$nama = $data->nama_lengkap;
	$email = $data->email;
	$jk = $data->jenis_kelamin;
	if ($jk=="L") {
		$jk1="checked";
		$jk2="";
	}
	else if ($jk=="P") {
		$jk1="";
		$jk2="checked";
	}
	$tempat = $data->tempat_lahir;
	$alamat= $data->alamat_pendaftar;
	$tanggal= $data->tanggal_lahir;
	$asalsekolah= $data->asal_sekolah;
	$hp = $data->no_hp;
	$telepon = $data->telepon_rumah;
	$button_simpan = "";
	$button_edit = "<button type=\"submit\" class=\"btn btn-danger\" name=\"edit\">EDIT</button>";
	$gambar = "<div class=\"form-group\">
							<label for=\"\">Unggah Gambar</label>
							<input type=\"file\" name=\"gambar\">
						</div>";

}
else
{
	$id="";
	$nama = "";
	$email = "";
	$jk = "";
	$tempat = "";
	$alamat= "";
	$tanggal= "";
	$asalsekolah= "";
	$hp = "";
	$telepon = "";
	$button_edit = "";
	$button_simpan = "<button type=\"submit\" class=\"btn btn-primary\" name=\"simpan\">SIMPAN</button>";
	$gambar = "<div class=\"form-group\">
							<label for=\"\">Unggah Gambar</label>
							<input type=\"file\" name=\"gambar\">
						</div>";
}	
 ?>

<div class="row">
	<div class="col-lg-12">
        <h1 class="page-header">Edit Biodata Siswa</h1>
	</div>
</div>
    <!-- /.col-lg-12 -->
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<form action="proseseditbiodata.php" enctype="multipart/form-data" method="POST" role="form">
		
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Nama</label>
							<input type="text" name="nama" value="<?php echo $nama; ?>" class="form-control" id="" placeholder="Cth: Sutarman">
						</div>
					</div>
					<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
						<div class="form-group">
							<label for="">Email</label>
							<input type="text" name="email" value="<?php echo $email; ?>" class="form-control" id="" placeholder="Cth: contoh@example.com">
						</div>
		 			</div>
		 		</div>
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Jenis Kelamin</label>
							<div class="radio">
								<label>
									<input type="radio" <?php echo $jk1 ?> name="jk" id="input" value="L" >
									Laki-laki
								</label>
								<label>
									<input type="radio" <?php echo $jk2 ?> name="jk" id="input" value="P">
									Perempuan
								</label>
							</div>
						</div>

		 			</div>
		 		</div>
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Tempat Lahir</label>
							<input type="text" value="<?php echo $tempat; ?>" name="tempat" class="form-control" id="" placeholder="Cth: Bandung">
						</div>
					</div>
					<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
						<div class="form-group">
							<label for="">Tanggal Lahir</label>
							<input type="text" value="<?php echo $tanggal ?>" name="tanggal" class="form-control" id="" placeholder="Cth: 1995-08-01">
						</div>
		 			</div>
		 		</div>
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Alamat Rumah</label>
							<input type="text" value="<?php echo $alamat; ?>" name="alamat" class="form-control" id="" placeholder="Cth: Jalan Siliwangi, Bandung">
						</div>
					</div>
					<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
						<div class="form-group">
							<label for="">Asal Sekolah</label>
							<input type="text" value="<?php echo $asalsekolah ?>" name="asalsekolah" class="form-control" id="" placeholder="Cth: SMKN 1 Bandung">
						</div>
		 			</div>
		 		</div>
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<div class="form-group">
							<label for="">Telepon</label>
							<input type="text" name="telepon" value="<?php echo $telepon ?>" class="form-control" id="" placeholder="Cth: 022678768">
						</div>
					</div>
					<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
						<div class="form-group">
							<label for="">HP</label>
							<input type="text" name="hp" value="<?php echo $hp ?>" class="form-control" id="" placeholder="Cth: 089699929549">
						</div>
		 			</div>
		 		</div>
		 		<div class="row">
		 			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		 				<?php echo $gambar; ?>
					</div>
					
		 		</div>
		 		<input type="hidden" name="id" value="<?php echo $id; ?>">
		 		

		 		
				

		
			
		
			<?php echo $button_simpan; ?> &nbsp;<?php echo $button_edit; ?>
		</form>
	</div>
</div>
