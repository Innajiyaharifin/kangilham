
   <!-- jQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
        <script src="js/dataTables.bootstrap.js"></script>  

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>
    <script type="text/javascript" src="js/morris/morris.js"></script>
      <script type="text/javascript" src="js/morris/rapa.js"></script>

        <?php
if (isset($_GET['menu'])) 
{
      if ($_GET['menu']=="data_pendaftar")
      {

        ?>
        <script>
          $(document).ready(function() 
          {
            var t = $('#datapendaftar').DataTable( {
                "ajax": "ajax_data_pendaftar.php",
                "order": [[ 0, 'asc' ]],
                "columns": [
                    { 
                        "data": "No",
                
                    },
                    { "data": "Nama Lengkap" },
                    { "data": "Alamat Pendaftar" },
                    { "data": "Jenis Kelamin" },
                    { "data": "Lihat Detail",
                       "width": "250px", 
                     },

                ]
            } );
        } );
        </script>
    <?php 
      }
    ?>
        <script>
        $(document).ready(function() {
            var t = $('#semuasoal').DataTable( {
                "ajax": "ajax_semuasoal.php",
                "order": [[ 0, 'asc' ]],
                "columns": [
                    { 
                        "data": "No",
                
                    },
                    { "data": "Soal" },
                    { "data": "Jawaban Benar" },
                    { "data": "Jawaban Salah 1" },
                    { "data": "Jawaban Salah 2" },
                    { "data": "Jawaban Salah 3" },
                 
                    { "data": "Lihat Detail",
                       "width": "250px", 
                     },

                ]
            } );
        } );
    </script>
 
    <script>
        $(document).ready(function() {
            var t = $('#seleksi').DataTable( {
                "ajax": "ajax_seleksi.php?kuota=<?php echo $data->kuota; ?>&grade=<?php echo $data->passing_grade; ?>",
                "order": [[ 0, 'asc' ]],
                "columns": [
                    { 
                        "data": "No",
                
                    },
                    { "data": "namalengkap" },
                    { "data": "username" },
                    { "data": "nilaiw" },
                    { "data": "nilaia" },
                    { "data": "nilaiu" },
                    { "data": "total" },

                ]
            } );
        } );
    </script> 
    
        <?php
    }
     ?>
    
    <?php if ($_GET['menu']=="laporanditerima") { ?>
    <script>
      function realisasi(){
            
        $("#response").hide(); //sebagai div response (gaya2 loading image aja :D)
        
        $.ajax({
          url: "ajax_laporanditerima.php", //ambil data dari data.php
          cache: false, //data ga di simpan ke browser
          type: "GET", //tipe sinkron GET, bisa pake post, terserah aja
          dataType: "json", //data tipe nya sebagai json
          timeout:3000, //set 3 detik respon, jika lama berarti gagal
          beforeSend: function() {
                    
            $("#response").show(); //penggaya loading muncul ;D
            $('#response').html("<img src='ajax-loader.gif' />");           
          },
          success : function (data) {
          
        $("#response").hide(); //penggaya loading dimatikan :(  
           var graph = Morris.Line({ //di sini inisialkan graph sebagai morris chart area
             element: 'laporanditerima', //masukin chart nya nanti di div id=contoh-chart
             data: data, //set data dari callback success function
              xkey: 'y', //ini yang tadi sebagai data x (bawah)
              ykeys: ['jumlah'], //datanya berupa jumlah penjualan tadi, json data
              labels: ['Siswa Diterima'], //Label data dibikin Penjualan        
              lineColors: ['#2b44d2'], //bikin warna line nya


          });
        }
        });
        



        }
      $(document).ready(function()
      {     
        realisasi(); //nah nanti dipanggil di sini
      });                
      </script> 

  <?php
  }


  ?>
