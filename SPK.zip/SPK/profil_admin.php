	<div class="col-lg-12">
    	<h1 class="page-header">Profil Admin</h1>
	</div>

	<div class="row">
		<div class="col-md-2 col-xs-6">
		<?php  
			
			    $id_pengguna= $_SESSION['id_pengguna'];

			    $table = "pengguna as a,tb_admin as b";
			    $field = "a.id_pengguna, a.nama_lengkap, a.username, a.password,b.foto_profil";
			    $where = "a.id_pengguna='$id_pengguna' and a.id_pengguna=b.id_pengguna";
			    $activerecord = new activerecord;
				$proses = $activerecord->getwhere($table, $field, $where);
				$data=$proses->fetch_object();

			?>

			<a href="index.php?menu=ubah_foto"><img src="images/profil/<?php echo $data->foto_profil ?>" class="img-responsive img-thumbnail"  alt="sari.jpg" ></a>
    				
		</div>
		<div class="col-md-6">

			<div >
				<div>
					<table class="table table-hover" >
						<tr class="warning">
							<td>Nama Lengkap</td>
							<td>:</td>
							<td><?php echo $data->nama_lengkap;?></td>
							
						</tr>
						<tr class="warning">
							<td>Username</td>
							<td>:</td>
							<td><?php echo $data->username;?></td>
							
						</tr>
						</table>
						<div class="row">
							<div class="col-md-7 ">
							<a href="index.php?menu=edit_admin"class="btn btn-primary">EDIT</a>
							</div>
						</div>
				</div>
			</div>
		</div>
		
	</div>
	
