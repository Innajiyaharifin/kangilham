<?php 
$grade = $_POST['grade'];
$kuota = $_POST['kuota'];
include 'library/activerecord.php';
$activerecord = new activerecord;
$proses = $activerecord->getUpdate("tb_kuota","kuota='$kuota', passing_grade='$grade'","id=1");
if ($proses) {
	header("location: index.php?menu=seleksi");
}
else
{
	echo "error";
}

 ?>