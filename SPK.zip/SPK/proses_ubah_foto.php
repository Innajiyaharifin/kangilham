<?php 
session_start();
include_once 'library/activerecord.php';
	$id_pengguna = $_SESSION['id_pengguna'];
	$activerecord = new activerecord;
  $namaFile = $_FILES['gambar']['name']; // berisi nama file yang sedang di gambar
  $tipeFile = $_FILES['gambar']['type']; // mime type dari file yang sedang di upload, jika browser memberikan informasi ini. Contoh : image/gif, image/jpg dll
  $ukuranFile = $_FILES['gambar']['size']; // ukuran size file yang diupload dalam byte
  $errorFile = $_FILES['gambar']['error']; // error code yang berhubungan dengan file yang sedang di upload
  //cek gambar bener ga?
  
    if($ukuranFile > 0 || $errorFile == 0)
    {
      if($tipeFile == "image/png" or $tipeFile == "image/jpg" or  $tipeFile == "image/jpeg")
      {
        /* 
          $_FILES['upload']['tmp_name'] adalah nama file temporer dari file yang sedang diupload yang disimpan di temporari folder server
          move_uploaded_file adalah fungsi untuk mengupload file dari direktori klien ke server
        */
        $move = move_uploaded_file($_FILES['gambar']['tmp_name'], 'images/profil/'.$namaFile);
        
        // perintah SQL untuk melakukan input data
        
       
        $proses = $activerecord->getUpdate("tb_admin","foto_profil='$namaFile'","id_pengguna='$id_pengguna'");
        // mysql_query adalah fungsi untuk mengeksekusi perintah SQL

        
        if($move && $proses)
        {
          $_SESSION['flash']['info'] = "success";
				$_SESSION['flash']['message'] = "Berhasil!!... Profil anda sudah berubah";
				header("location: index.php?menu=profil_admin");
        }
        else
        {
          $_SESSION['flash']['info'] = "danger";
			$_SESSION['flash']['message'] = "Terjadi kesalahan ".$activerecord->error();
			header("location: index.php?menu=ubah_foto");

        }
      }
      else
      {
         $_SESSION['flash']['info'] = "danger";
			$_SESSION['flash']['message'] = "Format harus JPG/PNG";
			header("location: index.php?menu=ubah_foto");
      }
    }
    else
    {
 		$_SESSION['flash']['info'] = "warning";
			$_SESSION['flash']['message'] = "Tidak ada yang berubah";
			header("location: index.php?menu=ubah_foto");
    }

 ?>