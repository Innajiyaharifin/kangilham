<?php 
include_once 'library/activerecord.php';
session_start();
if (isset($_POST['simpan'])) 
{
	
	$nama_lengkap=$_POST['nama_lengkap'];
	$username=$_POST['username'];
	$password=md5($_POST['password']);
	$pertanyaan=$_POST['pertanyaan'];
	$jawaban=md5($_POST['jawaban']);

	$table = "pengguna"; //table yang digunakan
	$value = "'', '$nama_lengkap', '$username', '$password', '$pertanyaan', '$jawaban','1'"; //field yang ditampilkan
	

	$activerecord = new activerecord;
	$proses = $activerecord->getInsert($table,$value); //nama table, nama field, where nya
	if ($proses) 
	{
		date_default_timezone_set("Asia/Jakarta");
		$date= date("Y/m/d h:i:s");
		$table = "pengguna";
		$field = "*";
		$where = "username='$username' order by id_pengguna desc limit 1";
		$proses = $activerecord->getWhere($table, $field, $where);
		if ($proses) {
			$data = $proses->fetch_object();
			$insert = $activerecord->getInsert("tb_admin","'','user.png','$data->id_pengguna','$date','$date'");
			$_SESSION['flash']['message']="Tambah admin berhasil";
        $_SESSION['flash']['info']="success";
        echo "<script>document.location = 'index.php?menu=tambahadmin	'</script>";
		}

		
	}
	else
	{
		echo "error";
	}

}


 ?>