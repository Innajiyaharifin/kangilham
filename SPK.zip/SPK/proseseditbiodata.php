<?php
if (isset($_POST['edit'])) {
	require 'library/activerecord.php';
$id=$_POST['id'];
$nama = $_POST['nama'];
$email = $_POST['email'];
$jk =$_POST['jk'];
$tempat = $_POST['tempat'];
$tanggal = $_POST['tanggal'];
$alamat = $_POST['alamat'];
$asalsekolah = $_POST['asalsekolah'];
$telepon = $_POST['telepon'];
$hp = $_POST['hp'];

$gambar = $_FILES['gambar']['name']; // berisi nama file yang sedang di gambar
$tipeFile = $_FILES['gambar']['type']; // mime type dari file yang sedang di gambar, jika browser memberikan informasi ini. Contoh : image/gif, image/jpg dll
$ukuranFile = $_FILES['gambar']['size']; // ukuran size file yang digambar dalam byte
$errorFile = $_FILES['gambar']['error']; // error code yang berhubungan dengan file yang sedang di gambar
$direktori_gambar = "images/profil/$gambar";
//cek gambar bener ga?

    if($ukuranFile > 0 || $errorFile == 0)
    {
            /* 
                $_FILES['gambar']['tmp_name'] adalah nama file temporer dari file yang sedang diupload yang disimpan di temporari folder server
                move_uploaded_file adalah fungsi untuk mengupload file dari direktori klien ke server
            */
            $move = move_uploaded_file($_FILES['gambar']['tmp_name'], $direktori_gambar );
            
            // perintah SQL untuk melakukan input data
            session_start();
            $id_user = $_SESSION['id_pengguna'];
            $activerecord=new activerecord;
            $table = "biodata";
            $value = "jenis_kelamin='$jk',alamat_pendaftar='$alamat',tempat_lahir='$tempat',tanggal_lahir='$tanggal',asal_sekolah='$asalsekolah',no_hp='$hp',telepon_rumah='$telepon',email='$email',photo_pendaftar='$gambar'";
            $where = "id_pendaftar='$id'";
            $proses=$activerecord->getUpdate($table,$value,$where);
            
            if($move && $proses)
            {
                $_SESSION['flash']['message']="Biodata telah diubah";
                $_SESSION['flash']['info']="success";
                echo "<script>document.location = 'index.php?menu=biodata	'</script>";
            }
            else
            {
                echo "<script>alert('gagal')".$mysqli->error."</script>";

            }
    }
    else
    {
        
            session_start();
            $id_user = $_SESSION['id_pengguna'];
            $activerecord=new activerecord;
            $table = "biodata";
            $value = "jenis_kelamin='$jk',alamat_pendaftar='$alamat',tempat_lahir='$tempat',tanggal_lahir='$tanggal',asal_sekolah='$asalsekolah',no_hp='$hp',telepon_rumah='$telepon',email='$email'";
            $where = "id_pendaftar='$id'";
            $proses=$activerecord->getUpdate($table,$value,$where);
            
            if($proses)
            {
                $_SESSION['flash']['message']="Biodata telah diubah";
                $_SESSION['flash']['info']="success";
                echo "<script>document.location = 'index.php?menu=biodata   '</script>";
                //echo "<script>document.location = 'main_admin.php?url_admin=dataguru'</script>";
            }
            else
            {
                echo "<script>alert('gagal')".$mysqli->error."</script>";

            }
    }



}
