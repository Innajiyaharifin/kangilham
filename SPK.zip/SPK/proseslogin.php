<?php 
include_once 'library/activerecord.php';
session_start();
if (ISSET($_POST['simpan'])) 
{
	$username=$_POST['username'];
	$password=md5($_POST['password']);

	$table = "pengguna"; //table yang digunakan
	$field = "*"; //field yang ditampilkan
	$where = "username='$username' and password='$password'"; //kondisi yang diinginkan

	$activerecord = new activerecord;
	$proses = $activerecord->getWhere($table,$field,$where); //nama table, nama field, where nya
	if ($data = $proses->fetch_object()) 
	{
		$_SESSION['level']=$data->level;
		$_SESSION['id_pengguna']=$data->id_pengguna;
		header("location: index.php");
	}
	else
	{
		echo "<script> alert('username atau password salah') ;document.location='login.php'; </script>";
	}

}





 ?>